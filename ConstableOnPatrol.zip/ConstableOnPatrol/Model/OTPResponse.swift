//
//  OTPResponse.swift
//  ConstableOnPatrol
//
//  Created by Mac on 15/07/24.
//

import UIKit

struct OTPResponse: Decodable {
//    let otp: String
    let msg : String
    let success : Bool
//    let token : String?
}
