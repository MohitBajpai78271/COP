import UIKit

struct VerifyOTPResponse: Decodable {
    let success: Bool
    let msg: String
}
